import 'dart:convert';
import 'package:http/http.dart' as http;
import 'movie_model.dart';

class MovieService {
  static const String _apiKey = '40be880f6d3ff852c2d8c45aaf0f8685';
  static const String _baseUrl = 'https://api.themoviedb.org/3';

  Future<List<MovieModel>> fetchNowPlaying() async {
    final uri = Uri.parse('$_baseUrl/movie/now_playing?api_key=$_apiKey&language=id-ID');
    final response = await http.get(uri).timeout(
      const Duration(seconds: 10),
      onTimeout: () => throw Exception('Request timeout'),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List<dynamic> results = data['results'];
      return results.map((json) => MovieModel.fromJson(json)).toList();
    } else {
      throw Exception('Gagal memuat film. Status: ${response.statusCode}');
    }
  }
}