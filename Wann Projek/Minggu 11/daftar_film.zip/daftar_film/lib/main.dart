import 'package:flutter/material.dart';
import 'movie_list_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Movie DB App',
      theme: ThemeData(colorSchemeSeed: Colors.blue),
      home: const MovieListScreen(),
    );
  }
}