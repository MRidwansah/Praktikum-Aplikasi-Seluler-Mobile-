class MovieModel {
  int? id;
  String? title;
  String? overview;
  String? posterPath;
  double? voteAverage;
  String? releaseDate;

  MovieModel({
    this.id,
    this.title,
    this.overview,
    this.posterPath,
    this.voteAverage,
    this.releaseDate,
  });

  MovieModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    overview = json['overview'];
    posterPath = json['poster_path'];
    voteAverage = (json['vote_average'] as num?)?.toDouble();
    releaseDate = json['release_date'];
  }

  String get fullPosterUrl =>
      posterPath != null
          ? 'https://image.tmdb.org/t/p/w500$posterPath'
          : '';
}