import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart'; 
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'item_model.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplikasi List Item',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: ItemListPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ItemListPage extends StatefulWidget {
  @override
  State<ItemListPage> createState() => _ItemListPageState();
}

class _ItemListPageState extends State<ItemListPage> {
  List<ItemModel> _items = [];
  List<ItemModel> _filteredItems = [];

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();

  final List<ItemModel> _dummyItems = [
    ItemModel(id: 1, name: 'Laptop', description: 'Laptop gaming'),
    ItemModel(id: 2, name: 'Mouse', description: 'Mouse wireless'),
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  ImageProvider? _getImageProvider(String? path) {
    if (path == null || path.isEmpty) return null;
    try {
      if (kIsWeb) {
        return NetworkImage(path); 
      } else {
        return FileImage(File(path)); 
      }
    } catch (e) {
      return null;
    }
  }

  Future<void> _loadData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? itemsString = prefs.getString('items_list');

    if (itemsString != null) {
      List<dynamic> itemsMap = json.decode(itemsString);
      setState(() {
        _items = itemsMap.map((item) => ItemModel.fromMap(item)).toList();
        _filteredItems = List.from(_items);
      });
    } else {
      setState(() {
        _items = List.from(_dummyItems);
        _filteredItems = List.from(_items);
      });
      await _saveData();
    }
  }

  Future<void> _saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<Map<String, dynamic>> itemsMap =
        _items.map((item) => item.toMap()).toList();
    String itemsString = json.encode(itemsMap);
    await prefs.setString('items_list', itemsString);
  }

  void _runFilter(String enteredKeyword) {
    List<ItemModel> results = [];
    if (enteredKeyword.isEmpty) {
      results = List.from(_items);
    } else {
      results = _items
          .where((item) =>
              item.name.toLowerCase().contains(enteredKeyword.toLowerCase()))
          .toList();
    }
    setState(() {
      _filteredItems = results;
    });
  }

  Future<void> _addItem(String? imagePath) async {
    if (_nameController.text.isEmpty || _descController.text.isEmpty) return;

    int newId = _items.isNotEmpty ? _items.last.id + 1 : 1;
    ItemModel newItem = ItemModel(
      id: newId,
      name: _nameController.text,
      description: _descController.text,
      imagePath: imagePath,
    );

    setState(() {
      _items.add(newItem);
      _runFilter(_searchController.text);
    });

    await _saveData();
    _nameController.clear();
    _descController.clear();
    Navigator.pop(context);
  }

  Future<void> _editItem(int id, String? imagePath) async {
    if (_nameController.text.isEmpty || _descController.text.isEmpty) return;

    setState(() {
      int index = _items.indexWhere((item) => item.id == id);
      if (index != -1) {
        _items[index] = ItemModel(
          id: id,
          name: _nameController.text,
          description: _descController.text,
          imagePath: imagePath,
        );
      }
      _runFilter(_searchController.text);
    });

    await _saveData();
    _nameController.clear();
    _descController.clear();
    Navigator.pop(context);
  }

  Future<void> _deleteItem(int id) async {
    setState(() {
      _items.removeWhere((item) => item.id == id);
      _runFilter(_searchController.text);
    });
    await _saveData();
  }

  void _showFormDialog({ItemModel? item}) {
    String? currentImagePath = item?.imagePath;

    if (item != null) {
      _nameController.text = item.name;
      _descController.text = item.description;
    } else {
      _nameController.clear();
      _descController.clear();
    }

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            bool hasImage = currentImagePath != null && currentImagePath!.isNotEmpty;
            return AlertDialog(
              title: Text(item == null ? 'Tambah Item' : 'Edit Item'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    GestureDetector(
                      onTap: () async {
                        final picker = ImagePicker();
                        final pickedFile = await picker.pickImage(source: ImageSource.gallery);
                        if (pickedFile != null) {
                          setStateDialog(() {
                            currentImagePath = pickedFile.path;
                          });
                        }
                      },
                      child: Container(
                        height: 100,
                        width: 100,
                        decoration: BoxDecoration(
                          color: Colors.grey[300],
                          shape: BoxShape.circle,
                          image: hasImage
                              ? DecorationImage(
                                  image: _getImageProvider(currentImagePath)!,
                                  fit: BoxFit.cover,
                                )
                              : null,
                        ),
                        child: !hasImage
                            ? Icon(Icons.add_a_photo, size: 40, color: Colors.grey[700])
                            : null,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text('Ketuk ikon untuk foto', style: TextStyle(fontSize: 12, color: Colors.grey)),
                    SizedBox(height: 16),
                    TextField(
                      controller: _nameController,
                      decoration: InputDecoration(labelText: 'Nama Item'),
                    ),
                    TextField(
                      controller: _descController,
                      decoration: InputDecoration(labelText: 'Deskripsi'),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Batal'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (item == null) {
                      _addItem(currentImagePath);
                    } else {
                      _editItem(item.id, currentImagePath);
                    }
                  },
                  child: Text('Simpan'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar Item'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              onChanged: (value) => _runFilter(value),
              decoration: InputDecoration(
                labelText: 'Cari Item',
                suffixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ),
          Expanded(
            child: _filteredItems.isEmpty
                ? Center(child: Text('Tidak ada data. Tambahkan Item Baru'))
                : ListView.builder(
                    itemCount: _filteredItems.length,
                    itemBuilder: (context, index) {
                      final item = _filteredItems[index];
                      bool hasImage = item.imagePath != null && item.imagePath!.isNotEmpty;
                      return Card(
                        margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: ListTile(
                          leading: CircleAvatar(
                            radius: 25,
                            backgroundColor: Colors.blue,
                            backgroundImage: _getImageProvider(item.imagePath),
                            child: !hasImage
                                ? Text('${index + 1}', style: TextStyle(color: Colors.white))
                                : null,
                          ),
                          title: Text(item.name, style: TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text(item.description),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: Icon(Icons.edit, color: Colors.orange),
                                onPressed: () => _showFormDialog(item: item),
                              ),
                              IconButton(
                                icon: Icon(Icons.delete, color: Colors.red),
                                onPressed: () => _deleteItem(item.id),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showFormDialog(),
        child: Icon(Icons.add),
      ),
    );
  }
}