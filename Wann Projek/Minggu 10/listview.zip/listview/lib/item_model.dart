class ItemModel {
  final int id;
  final String name;
  final String description;
  final String? imagePath; // Tambahan: Boleh kosong 

  ItemModel({
    required this.id,
    required this.name,
    required this.description,
    this.imagePath,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'imagePath': imagePath, // Simpan path gambar
    };
  }

  factory ItemModel.fromMap(Map<String, dynamic> map) {
    return ItemModel(
      id: map['id'],
      name: map['name'],
      description: map['description'],
      imagePath: map['imagePath'], // Ambil path gambar
    );
  }
}