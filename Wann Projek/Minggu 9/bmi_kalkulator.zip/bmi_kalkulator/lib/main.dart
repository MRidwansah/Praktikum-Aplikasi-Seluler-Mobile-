import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'pages/input_page.dart';
import 'utils/theme.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final AudioPlayer _player = AudioPlayer();
  bool isPlaying = false;

  Future<void> playMusic() async {
    try {
      await _player.setReleaseMode(ReleaseMode.loop);

      await _player.play(AssetSource('audio/kicau.mp3'));

      setState(() {
        isPlaying = true;
      });
    } catch (e) {
      debugPrint("ERROR AUDIO: $e");
    }
  }

  Future<void> stopMusic() async {
    await _player.stop();
    setState(() {
      isPlaying = false;
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kalkulator BMI',
      theme: appTheme(),
      debugShowCheckedModeBanner: false,
      home: const InputPage(),
      
      builder: (context, child) {
        return Scaffold(
          resizeToAvoidBottomInset: false, 
          backgroundColor: Colors.transparent,
          body: Stack(
            children: [
              if (child != null) Positioned.fill(child: child),

              // Lapisan kucing
              if (isPlaying)
                Positioned.fill(
                  child: IgnorePointer(
                    child: Center(
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.black26,
                              blurRadius: 15,
                              spreadRadius: 2,
                              offset: Offset(0, 5),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: Image.network(
                            'https://media1.tenor.com/m/Xn3TfHpAJiMAAAAd/scuba-cat-scuba.gif',
                            width: 200,
                            height: 200,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
          
          floatingActionButton: FloatingActionButton(
            onPressed: () async {
              if (isPlaying) {
                await stopMusic();
              } else {
                await playMusic();
              }
            },
            child: Icon(
              isPlaying ? Icons.music_off : Icons.music_note,
            ),
          ),
        );
      },
    );
  }
}