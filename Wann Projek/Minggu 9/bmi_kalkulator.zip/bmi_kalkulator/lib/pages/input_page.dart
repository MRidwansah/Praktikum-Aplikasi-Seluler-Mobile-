// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/bmi_calculator.dart';
import '../utils/theme.dart';
import 'result_page.dart';

class InputPage extends StatefulWidget {
  const InputPage({super.key});

  @override
  State<InputPage> createState() => _InputPageState();
}

class _InputPageState extends State<InputPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _weightController = TextEditingController();
  final _heightController = TextEditingController();

  String? _selectedCategory;
  String _selectedGender = 'Laki-laki';

  final List<Map<String, String>> _categories = [
    {'value': 'Anak-anak', 'label': 'Anak-anak (5–17 th)'},
    {'value': 'Remaja', 'label': 'Remaja (17–25 th)'},
    {'value': 'Dewasa', 'label': 'Dewasa (25+ th)'},
  ];

  @override
  void dispose() {
    _nameController.dispose();
    _weightController.dispose();
    _heightController.dispose();
    super.dispose();
  }

  void _hitungBMI() {
    if (_formKey.currentState!.validate()) {
      final calculator = BmiCalculator(
        weight: double.parse(_weightController.text),
        height: double.parse(_heightController.text),
      );

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ResultPage(
            nama: _nameController.text,
            bmi: calculator.bmi,
            gender: _selectedGender,
            kategori: _selectedCategory!,
            weight: calculator.weight,
            height: calculator.height,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kalkulator BMI'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: const [kPrimaryColor, kAccentColor],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: const [
                    Icon(Icons.monitor_weight_outlined,
                        color: Colors.white, size: 40),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hitung BMI Anda',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            'Indeks Massa Tubuh',
                            style: TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 24),

              _sectionLabel('Data Pribadi', Icons.person),
              SizedBox(height: 10),

              // Nama
              TextFormField(
                controller: _nameController,
                validator: (v) =>
                    v == null || v.isEmpty ? 'Nama wajib diisi' : null,
                decoration: InputDecoration(
                  labelText: 'Nama',
                  prefixIcon: Icon(Icons.person),
                ),
              ),

              SizedBox(height: 16),

              // Berat & Tinggi
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _weightController,
                      validator: (v) =>
                          v == null || v.isEmpty ? 'Wajib' : null,
                      decoration: InputDecoration(
                        labelText: 'Berat',
                        suffixText: 'kg',
                      ),
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly
                      ],
                    ),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    child: TextFormField(
                      controller: _heightController,
                      validator: (v) =>
                          v == null || v.isEmpty ? 'Wajib' : null,
                      decoration: InputDecoration(
                        labelText: 'Tinggi',
                        suffixText: 'cm',
                      ),
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly
                      ],
                    ),
                  ),
                ],
              ),

              SizedBox(height: 24),

              _sectionLabel('Kategori Usia', Icons.cake),
              SizedBox(height: 10),

              DropdownButtonFormField<String>(
                initialValue: _selectedCategory,
                hint: Text('Pilih kategori'),
                items: _categories.map((e) {
                  return DropdownMenuItem(
                    value: e['value'],
                    child: Text(e['label']!),
                  );
                }).toList(),
                onChanged: (v) {
                  setState(() {
                    _selectedCategory = v;
                  });
                },
              ),

              SizedBox(height: 24),

              _sectionLabel('Jenis Kelamin', Icons.wc),
              SizedBox(height: 8),

              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Color(0xFFE0E0E0)),
                ),
                child: Column(
                  children: [
                    RadioListTile<String>(
                      title: Row(
                        children: const [
                          Icon(Icons.male, color: Colors.blue),
                          SizedBox(width: 6),
                          Text('Laki-laki'),
                        ],
                      ),
                      value: 'Laki-laki',
                      groupValue: _selectedGender,
                      onChanged: (value) {
                        setState(() {
                          _selectedGender = value!;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      title: Row(
                        children: const [
                          Icon(Icons.female, color: Colors.pink),
                          SizedBox(width: 6),
                          Text('Perempuan'),
                        ],
                      ),
                      value: 'Perempuan',
                      groupValue: _selectedGender,
                      onChanged: (value) {
                        setState(() {
                          _selectedGender = value!;
                        });
                      },
                    ),
                  ],
                ),
              ),

              SizedBox(height: 30),

              ElevatedButton(
                onPressed: _hitungBMI,
                child: Text('Hitung BMI'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionLabel(String text, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 16),
        SizedBox(width: 6),
        Text(text, style: TextStyle(fontWeight: FontWeight.bold)),
      ],
    );
  }
}