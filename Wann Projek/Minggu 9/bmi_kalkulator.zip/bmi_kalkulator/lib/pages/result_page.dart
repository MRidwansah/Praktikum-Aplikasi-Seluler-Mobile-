import 'package:flutter/material.dart';
import '../utils/theme.dart';
import '../utils/bmi_calculator.dart';

class ResultPage extends StatelessWidget {
  final String nama, gender, kategori;
  final double bmi, weight, height; 

  const ResultPage({
    required this.nama,
    required this.bmi,
    required this.gender,
    required this.kategori,
    required this.weight, 
    required this.height, 
    super.key,
  });

  Color withOpacityFix(Color color, double opacity) {
    return color.withAlpha((opacity * 255).toInt());
  }

  String _getKategori() {
    if (bmi < 18.5) return 'Kurus';
    if (bmi < 25.0) return 'Normal';
    if (bmi < 30.0) return 'Gemuk';
    return 'Obesitas';
  }

  String _getSaran() {
    if (bmi < 18.5) {
      return 'Tingkatkan asupan kalori bergizi dan konsultasikan dengan ahli gizi.';
    } else if (bmi < 25.0) {
      return 'Pertahankan pola makan sehat dan olahraga rutin. Tubuh Anda ideal!';
    } else if (bmi < 30.0) {
      return 'Kurangi asupan lemak jenuh dan perbanyak aktivitas fisik harian.';
    } else {
      return 'Segera konsultasikan dengan dokter untuk program penurunan berat badan.';
    }
  }

  IconData _getKategoriIcon() {
    if (bmi < 18.5) return Icons.trending_down;
    if (bmi < 25.0) return Icons.check_circle;
    if (bmi < 30.0) return Icons.warning_amber_rounded;
    return Icons.dangerous_outlined;
  }

  double _getBmiPercentage() {
    return ((bmi - 10) / 30).clamp(0.0, 1.0);
  }

  @override
  Widget build(BuildContext context) {
    final bmiColor = getBmiColor(bmi);
    final kategoriLabel = _getKategori();
    
    final calculator = BmiCalculator(weight: weight, height: height);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Hasil BMI'),
        leading: const BackButton(),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Profile Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: withOpacityFix(Colors.black, 0.06),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 32,
                    backgroundColor: gender == 'Laki-laki'
                        ? Colors.blue.shade50
                        : Colors.pink.shade50,
                    child: Icon(
                      gender == 'Laki-laki' ? Icons.male : Icons.female,
                      size: 36,
                      color: gender == 'Laki-laki' ? Colors.blue : Colors.pink,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          nama,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey.shade800,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            _infoChip(
                                kategori, Icons.cake_outlined, Colors.purple),
                            const SizedBox(width: 6),
                            _infoChip(
                                gender,
                                Icons.wc_outlined,
                                gender == 'Laki-laki'
                                    ? Colors.blue
                                    : Colors.pink),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // BMI Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    withOpacityFix(bmiColor, 0.85),
                    bmiColor
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: withOpacityFix(bmiColor, 0.35),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                children: [
                  const Text(
                    'Indeks Massa Tubuh',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    bmi.toStringAsFixed(1),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 64,
                      fontWeight: FontWeight.w900,
                      height: 1,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(_getKategoriIcon(),
                          color: Colors.white, size: 22),
                      const SizedBox(width: 6),
                      Text(
                        kategoriLabel,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Progress
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: _getBmiPercentage(),
                      minHeight: 10,
                      backgroundColor: Colors.white30,
                      valueColor:
                          const AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Saran
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: withOpacityFix(bmiColor, 0.07),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                    color: withOpacityFix(bmiColor, 0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.lightbulb_outline,
                      color: bmiColor),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(_getSaran()),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // 🔥 FITUR BARU: Target Berat Badan Ideal
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: withOpacityFix(Colors.black, 0.06),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.monitor_weight_outlined, color: bmiColor),
                      const SizedBox(width: 8),
                      Text(
                        'Target Berat Ideal',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey.shade800,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Rentang ideal: ${calculator.minIdealWeight.toStringAsFixed(1)} kg - ${calculator.maxIdealWeight.toStringAsFixed(1)} kg',
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                    decoration: BoxDecoration(
                      color: withOpacityFix(bmiColor, 0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: withOpacityFix(bmiColor, 0.3)),
                    ),
                    child: Text(
                      calculator.targetWeightSuggestion,
                      style: TextStyle(
                        color: bmiColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 28),

            ElevatedButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.refresh),
              label: const Text('Hitung Ulang'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoChip(String label, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: withOpacityFix(color, 0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: color),
          const SizedBox(width: 4),
          Text(label,
              style: TextStyle(fontSize: 12, color: color)),
        ],
      ),
    );
  }
}