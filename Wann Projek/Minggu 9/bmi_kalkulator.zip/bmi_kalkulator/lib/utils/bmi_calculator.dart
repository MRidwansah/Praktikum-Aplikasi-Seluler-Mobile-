class BmiCalculator {
  final double weight;
  final double height; // in cm

  BmiCalculator({required this.weight, required this.height});

  double get bmi {
    final heightM = height / 100;
    return weight / (heightM * heightM);
  }

  String get kategori {
    if (bmi < 18.5) return 'Kurus';
    if (bmi < 25.0) return 'Normal';
    if (bmi < 30.0) return 'Gemuk';
    return 'Obesitas';
  }

  String get saran {
    if (bmi < 18.5) {
      return 'Tingkatkan asupan kalori dan konsultasikan dengan ahli gizi.';
    } else if (bmi < 25.0) {
      return 'Pertahankan pola makan sehat dan olahraga rutin!';
    } else if (bmi < 30.0) {
      return 'Kurangi asupan lemak dan perbanyak aktivitas fisik.';
    } else {
      return 'Segera konsultasikan dengan dokter untuk program penurunan berat badan.';
    }
  }

  // --- FITUR BARU: RENTANG & TARGET BERAT BADAN ---

  // Menghitung batas bawah berat badan ideal (BMI 18.5)
  double get minIdealWeight {
    final heightM = height / 100;
    return 18.5 * (heightM * heightM);
  }

  // Menghitung batas atas berat badan ideal (BMI 24.9)
  double get maxIdealWeight {
    final heightM = height / 100;
    return 24.9 * (heightM * heightM);
  }

  // Menghitung berapa kg yang harus dinaikkan/diturunkan
  String get targetWeightSuggestion {
    if (bmi < 18.5) {
      double target = minIdealWeight - weight;
      return 'Naikkan sekitar ${target.toStringAsFixed(1)} kg';
    } else if (bmi > 25.0) {
      double target = weight - maxIdealWeight;
      return 'Turunkan sekitar ${target.toStringAsFixed(1)} kg';
    } else {
      return 'Berat badan sudah ideal 🎯';
    }
  }

  static double calculate(double weight, double height) {
    final heightM = height / 100;
    return weight / (heightM * heightM);
  }
}